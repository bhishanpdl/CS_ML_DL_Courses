.. sidebar:: Homework 1

   :Author: Bhishan Poudel
   :Date: |today|


.. contents:: Table of Contents
   :depth: 3


Reports
========

.. toctree::
   :maxdepth: 4

   qn1
   qn2
   qn3



Source Codes
====================

.. toctree::
   :maxdepth: 4

   univariate
   multivariate
   polyfit
