Sphinx commands for documentation:

1. spallf code/scipy/
2. sp_dir2 scikit
3. spb_rstq
