softmaxExercise 
======================

.. automodule:: softmaxExercise
    :members:
    :undoc-members:
    :show-inheritance:
