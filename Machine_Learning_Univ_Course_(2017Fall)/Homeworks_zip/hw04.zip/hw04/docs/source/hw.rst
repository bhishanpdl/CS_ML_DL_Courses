Homework 4
=============================

.. image:: ../../rst/hw04-0.png
.. image:: ../../rst/hw04-1.png
.. image:: ../../rst/hw04-2.png


.. rm -r rst/*.png ; convert -quality 300 -density 100 rst/hw04.pdf rst/hw04.png
