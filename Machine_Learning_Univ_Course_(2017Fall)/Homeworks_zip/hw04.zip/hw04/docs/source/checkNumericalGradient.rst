checkNumericalGradient 
=============================

.. automodule:: checkNumericalGradient
    :members:
    :undoc-members:
    :show-inheritance:
