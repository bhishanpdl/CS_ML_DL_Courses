.. sidebar:: Homework 4

   :Author: Bhishan Poudel
   :Date: |today|


.. contents:: Table of Contents
   :depth: 3

Homework Question
===================

.. toctree::
   :maxdepth: 4

   hw

Reports
========

.. toctree::
   :maxdepth: 4

   qn1
   qn2
   qn3

Source Codes
====================

.. toctree::
  :maxdepth: 4
  
  checkNumericalGradient
  computeNumericalGradient
  softmax
  minibatch_softmax
  softmaxExercise
  scikit/softmaxExercise
