softmaxExercise 
======================

.. automodule:: scikit.softmaxExercise
    :members:
    :undoc-members:
    :show-inheritance:
