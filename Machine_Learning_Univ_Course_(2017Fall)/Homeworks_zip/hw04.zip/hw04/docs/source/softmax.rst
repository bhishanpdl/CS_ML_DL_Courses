softmax 
==============

.. automodule:: softmax
    :members:
    :undoc-members:
    :show-inheritance:
