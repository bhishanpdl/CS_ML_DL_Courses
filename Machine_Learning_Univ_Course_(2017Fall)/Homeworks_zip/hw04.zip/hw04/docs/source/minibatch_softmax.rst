minibatch\_softmax 
=========================

.. automodule:: minibatch_softmax
    :members:
    :undoc-members:
    :show-inheritance:
