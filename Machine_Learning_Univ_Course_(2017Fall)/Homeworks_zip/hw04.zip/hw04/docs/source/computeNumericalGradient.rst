computeNumericalGradient 
===============================

.. automodule:: computeNumericalGradient
    :members:
    :undoc-members:
    :show-inheritance:
