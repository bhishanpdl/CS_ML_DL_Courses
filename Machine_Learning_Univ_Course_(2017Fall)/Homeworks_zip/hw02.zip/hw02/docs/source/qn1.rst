Feature Scaling
=============================

Here I use Zscore normalization to normalize the design matrix X.

.. math:: z = \frac{x - \mu}{\sigma}

Where, mu is mean, and sigma is the standard deviation.
