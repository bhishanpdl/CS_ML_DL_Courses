univariate 
=================

.. automodule:: univariate
    :members:
    :undoc-members:
    :show-inheritance:
