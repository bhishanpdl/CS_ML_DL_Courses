polyfit 
==============

.. automodule:: polyfit
    :members:
    :undoc-members:
    :show-inheritance:
