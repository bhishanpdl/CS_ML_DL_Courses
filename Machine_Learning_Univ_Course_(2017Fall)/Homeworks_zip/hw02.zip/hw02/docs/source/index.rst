.. sidebar:: Homework 2

   :Author: Bhishan Poudel
   :Date: |today|


.. contents:: Table of Contents
   :depth: 3


Reports
========

.. toctree::
   :maxdepth: 4

   qn1
   qn2
   qn3
   qn4
   qn5



Source Codes
====================

.. toctree::
   :maxdepth: 4

   scaling
   univariate
   multivariate
   polyfit
