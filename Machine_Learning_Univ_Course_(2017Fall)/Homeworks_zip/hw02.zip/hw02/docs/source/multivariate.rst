multivariate 
===================

.. automodule:: multivariate
    :members:
    :undoc-members:
    :show-inheritance:
