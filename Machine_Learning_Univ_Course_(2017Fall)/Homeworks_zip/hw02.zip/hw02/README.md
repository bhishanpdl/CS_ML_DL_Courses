Homework 2
============

File structure:  
  - code   
  - images  
  - Extra  
  - docs  
  - rst  

All the source codes are in code directory.  
The output images generated from codes are placed in 'images'. This folder also contain BGD.png and SGD.png from class lecture.

docs/build/html/index.html is the report file.

rst folder has reports about each questions. I copy these rest files to the folder docs/source to compile using sphinx document generator, so that even if I delete docs folder, I have backup folder of rest files.



Caveats
========
The source codes requires python >=3.5 to compile.
For example the matrix multiply operator @ needs python >= 3.5.
