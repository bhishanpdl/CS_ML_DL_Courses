Homework 7
=============================

.. image:: ../../rst/hw07-0.png
.. image:: ../../rst/hw07-1.png
.. image:: ../../rst/hw07-2.png
.. image:: ../../rst/hw07-3.png


.. rm -r rst/*.png ; convert -quality 300 -density 100 rst/hw04.pdf rst/hw04.png
