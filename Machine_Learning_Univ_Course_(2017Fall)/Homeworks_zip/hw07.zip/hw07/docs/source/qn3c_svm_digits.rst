qn3c\_svm\_digits 
========================

.. automodule:: qn3c_svm_digits
    :members:
    :undoc-members:
    :show-inheritance:
