mc\_svm\_iris 
====================

.. automodule:: mc_svm_iris
    :members:
    :undoc-members:
    :show-inheritance:
