qn3b\_mcp 
================

.. automodule:: qn3b_mcp
    :members:
    :undoc-members:
    :show-inheritance:
