kperceptron 
==================

.. automodule:: kperceptron
    :members:
    :undoc-members:
    :show-inheritance:
