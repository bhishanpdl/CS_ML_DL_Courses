qn2\_svm\_text 
=====================

.. automodule:: qn2_svm_text
    :members:
    :undoc-members:
    :show-inheritance:
