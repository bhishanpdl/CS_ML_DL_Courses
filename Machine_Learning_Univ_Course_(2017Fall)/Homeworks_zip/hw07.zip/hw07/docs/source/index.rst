.. sidebar:: Homework 7

   :Author: Bhishan Poudel
   :Date: |today|


.. contents:: Table of Contents
   :depth: 3

Homework Question
===================

.. toctree::
   :maxdepth: 4

   hw

Reports
========

.. toctree::
   :maxdepth: 4


   hw07_qn2
   hw07_qn3a
   hw07_qn3b
   hw07_qn3c
   extraWork

Source Codes
====================

.. toctree::
  :maxdepth: 4
  
  qn2_svm_text
  perceptron
  kperceptron
  qn3a_dat_proc
  qn3b_mcp
  qn3c_svm_digits


ExtraWork
=========

.. toctree::
   :maxdepth: 4

   mc_svm_iris
   plot_text
