perceptron 
=================

.. automodule:: perceptron
    :members:
    :undoc-members:
    :show-inheritance:
